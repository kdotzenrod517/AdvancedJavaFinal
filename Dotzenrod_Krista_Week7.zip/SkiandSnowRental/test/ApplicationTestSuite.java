import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.skiandsnowrental.model.business.AllBusinessTests;
import com.skiandsnowrental.model.domain.AllDomainTests;
import com.skiandsnowrental.model.services.AllServiceTests;

@RunWith(Suite.class)
@SuiteClasses({ AllBusinessTests.class, AllServiceTests.class, AllDomainTests.class })
public class ApplicationTestSuite {

}
