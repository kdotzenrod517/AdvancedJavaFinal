package com.skiandsnowrental.model.business.manager;

import org.junit.Test;

import com.skiandsnowrental.model.domain.Customer;
import com.skiandsnowrental.model.domain.Rental;
import com.skiandsnowrental.model.domain.RentalComposite;
import com.skiandsnowrental.model.services.customerservice.ICustomerService;
import com.skiandsnowrental.model.services.rentalservice.IRentalService;

import junit.framework.TestCase;

/**
 * This unit test tests the SkiAndSnowRentalManager class.
 * 
 * @author krista.dotzenrod
 * 
 *
 */
public class SkiAndSnowRentalManagerTest extends TestCase {

	private SkiAndSnowRentalManager skiAndSnowRentalManager;
	private RentalComposite rentalComposite;
	private Rental rental;
	private Customer customer;

	@Test
	protected void setUp() throws Exception {
		super.setUp();

		skiAndSnowRentalManager = SkiAndSnowRentalManager.getInstance();

		rental = new Rental("28.9", "Snowboard", "Boots");
		customer = new Customer("Jenner", "Kylie", "hello@gmail.com", "pass", "867.5309");
		rentalComposite = new RentalComposite();
		rentalComposite.setRental(rental);
		rentalComposite.setCustomer(customer);

	}

	/**
	 * Test validate rental
	 */
	public final void testValidateRental() {
		boolean isAvailable = skiAndSnowRentalManager.validateRental(IRentalService.NAME, rentalComposite);
		assertFalse(isAvailable);
		System.out.println("testValidateRental PASSED");
	}

	public final void testValidateRentalFalse() {
		boolean isAvailable = skiAndSnowRentalManager.validateRental(IRentalService.NAME, rentalComposite);
		assertTrue(!isAvailable);
		System.out.println("testValidateRentalFalse PASSED");
	}

	public final void testAuthenticateCustomer() {
		boolean isAuthenticated = skiAndSnowRentalManager.authenticateCustomer(ICustomerService.NAME, rentalComposite);
		assertFalse(isAuthenticated);
		System.out.println("testAuthenticateCustomer PASSED");
	}

	public final void testAuthenticateCustomerFalse() {
		boolean isAuthenticated = skiAndSnowRentalManager.authenticateCustomer(ICustomerService.NAME, rentalComposite);
		assertTrue(!isAuthenticated);
		System.out.println("testAuthenticateCustomerFalse PASSED");
	}

	public final void testPerformActionOnValidateRental() {
		boolean action = skiAndSnowRentalManager.performAction("ValidateRental", rentalComposite);
		assertFalse(action);
		System.out.println("testPerformActionOnValidateRental PASSED");
	}

}
