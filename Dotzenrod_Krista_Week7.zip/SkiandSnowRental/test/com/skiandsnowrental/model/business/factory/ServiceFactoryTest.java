package com.skiandsnowrental.model.business.factory;

import com.skiandsnowrental.model.business.exception.ServiceLoadException;
import com.skiandsnowrental.model.services.customerservice.CustomerServiceImpl;
import com.skiandsnowrental.model.services.customerservice.ICustomerService;
import com.skiandsnowrental.model.services.factory.ServiceFactory;
import com.skiandsnowrental.model.services.rentalservice.IRentalService;
import com.skiandsnowrental.model.services.rentalservice.RentalServiceImpl;

import junit.framework.TestCase;

/**
 * 
 * @author kdotz
 *
 */
public class ServiceFactoryTest extends TestCase {
	ServiceFactory serviceFactory;

	public void setUp() throws Exception {
		serviceFactory = ServiceFactory.getInstance();
	}

	public void testGetInstance() {
		assertNotNull(serviceFactory);
	}

	/**
	 * Test Factory to return the rentalservice and assert it by checking it is
	 * an instance of RentalServiceImpl
	 * 
	 * This should be true since RentalServiceImpl implements IRentalService
	 */
	public void testGetRentalService() {
		IRentalService rentalService;
		try {
			rentalService = (IRentalService) serviceFactory.getService(IRentalService.NAME);
			assertTrue(rentalService instanceof RentalServiceImpl);
			System.out.println("testGetRentalService PASSED");
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fail("ServiceLoadException");
		}
	}

	public void testGetCustomerService() {
		ICustomerService customerService;
		try {
			customerService = (ICustomerService) serviceFactory.getService(ICustomerService.NAME);
			assertTrue(customerService instanceof CustomerServiceImpl);
			System.out.println("testGetCustomerService PASSED");
		} catch (ServiceLoadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			fail("ServiceLoadException");
		}
	}
}
