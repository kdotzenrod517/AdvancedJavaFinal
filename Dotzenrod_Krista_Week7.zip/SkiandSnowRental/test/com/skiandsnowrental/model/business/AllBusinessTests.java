package com.skiandsnowrental.model.business;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.skiandsnowrental.model.business.manager.SkiAndSnowRentalManagerTest;

/**
 * 
 * @author kdotz
 *
 */
@RunWith(Suite.class)
@SuiteClasses({ SkiAndSnowRentalManagerTest.class })
public class AllBusinessTests {

}
