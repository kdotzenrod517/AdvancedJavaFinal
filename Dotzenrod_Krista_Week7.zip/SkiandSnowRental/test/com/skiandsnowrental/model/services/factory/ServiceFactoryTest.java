package com.skiandsnowrental.model.services.factory;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import com.skiandsnowrental.model.services.customerservice.CustomerServiceImpl;
import com.skiandsnowrental.model.services.customerservice.ICustomerService;
import com.skiandsnowrental.model.services.rentalservice.IRentalService;
import com.skiandsnowrental.model.services.rentalservice.RentalServiceImpl;

public class ServiceFactoryTest {

	ServiceFactory serviceFactory;

	@Before
	public void setUp() throws Exception {
		serviceFactory = new ServiceFactory();
	}

	/**
	 * Test Factory to return the rentalservice and assert it by checking it is
	 * an instance of RentalServiceImpl
	 * 
	 * This should be true since RentalServiceImpl implements IRentalService
	 */

	@Test
	public void testGetRentalService() {
		IRentalService rentalService;
		try {
			rentalService = (IRentalService) serviceFactory.getService(IRentalService.NAME);
			assertTrue(rentalService instanceof RentalServiceImpl);
			System.out.println("testGetRentalService PASSED");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testGetCustomerService() {
		ICustomerService customerService;
		try {
			customerService = (ICustomerService) serviceFactory.getService(ICustomerService.NAME);
			assertTrue(customerService instanceof CustomerServiceImpl);
			System.out.println("testGetCustomerService PASSED");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
