package com.skiandsnowrental.model.services;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.skiandsnowrental.model.services.customerservice.CustomerServiceImplTest;
import com.skiandsnowrental.model.services.factory.ServiceFactoryTest;
import com.skiandsnowrental.model.services.rentalservice.RentalServiceImplTest;

@RunWith(Suite.class)
@SuiteClasses({ ServiceFactoryTest.class, RentalServiceImplTest.class, CustomerServiceImplTest.class })
public class AllServiceTests {

}
