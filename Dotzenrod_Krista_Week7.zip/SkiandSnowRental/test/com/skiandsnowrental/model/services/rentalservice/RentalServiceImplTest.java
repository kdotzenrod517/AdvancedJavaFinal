package com.skiandsnowrental.model.services.rentalservice;

import com.skiandsnowrental.model.domain.Rental;
import com.skiandsnowrental.model.domain.RentalComposite;
import com.skiandsnowrental.model.services.factory.ServiceFactory;
import java.util.List;
import java.util.Vector;

import junit.framework.TestCase;
import static org.junit.Assert.assertFalse;

;

public class RentalServiceImplTest extends TestCase {

    private ServiceFactory serviceFactory;
    private Rental rental;
    private RentalComposite rentalComposite = new RentalComposite();

    /**
     * @throws java.lang.Exception
     */
    @Override
    protected void setUp() throws Exception {
        super.setUp();

        serviceFactory = ServiceFactory.getInstance();

        rental = new Rental("28.9", "Snowboard", "Boots");
        rentalComposite.setRental(rental);
    }

    /**
     * Test method for
     * {@link com.skiandsnow.model.services.RentalService.RentalServiceImpl#storeRental(com.skiandsnow.model.domain.Rental)}
     * .
     */
    public void testStoreRental() {
        IRentalService rentalService;
        try {
            rentalService = (IRentalService) serviceFactory.getService(IRentalService.NAME);
            assertTrue(rentalService instanceof RentalServiceImpl);
            System.out.println("testStoreRental PASSED");
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void testRentalVec() {
        List<String> availableRentalsList = new Vector<String>(10, 1);
        int myVecIndex = 0;
        availableRentalsList.add("Skis");
        availableRentalsList.add("Snowboard");
        availableRentalsList.add("Helmet");
        availableRentalsList.add("Poles");
        String firstElement = availableRentalsList.get(myVecIndex);
        assertFalse("First rental does NOT equal second rental", firstElement.equals(myVecIndex++));
	System.out.println("testRentalVec PASSED");

    }

}
