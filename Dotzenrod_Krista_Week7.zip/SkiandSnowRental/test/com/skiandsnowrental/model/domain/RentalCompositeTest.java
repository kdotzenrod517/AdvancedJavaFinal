package com.skiandsnowrental.model.domain;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class RentalCompositeTest {

	/**
	 * Tests with a valid rental composite passed in
	 */
	@Test
	public void testValidate() {
		Rental r1 = new Rental("28.9", "Skis", "Poles and goggles");
		// r1.validate should assert to True since all variables
		// being passed to create a new Rental are all valid.
		assertTrue("r1 validates", r1.validate());
		System.out.println("testValidate PASSED");
	}

	/**
	 * Tests with an invalid rental composite passed in
	 */
	@Test
	public void testNotValidate() {
		Rental r1 = new Rental();
		// r1.validate should not pass here since we are not
		// sending in valid parameters - in the case of Rental
		// class, its valid only if all class variables are passed
		assertFalse("r1 does not validate", r1.validate());
		System.out.println("testNotValidate PASSED");
	}

	/**
	 * Tests if two rental composites are equal
	 */
	@Test
	public void testEqualsRental() {
		System.out.println("starting testEqualsRental()");
		Rental r1 = new Rental("28.9", "Skis", "Poles and goggles");
		Rental r2 = new Rental("28.9", "Skis", "Poles and goggles");
		// this should assert to true since the contents of
		// r1 and r2 class variables are identical.
		assertTrue("r1 equals r2", r1.equals(r2));
		System.out.println("testEqualsRental PASSED");
	}

	/**
	 * Tests if two rental composites are not equal
	 */
	@Test
	public void testNotEqualsCar() {
		System.out.println("starting testNotEqualsCar()");
		Rental r1 = new Rental("28.9", "Skis", "Poles and goggles");
		Rental r2 = new Rental("28.9", "Snowboard", "Goggles");
		// this should assert to false since the contents of
		// r1 and r2 class variables are NOT identical.
		assertFalse("r1 does NOT equal r2", r1.equals(r2));
		System.out.println("testNotEqualsRental PASSED");
	}
}
