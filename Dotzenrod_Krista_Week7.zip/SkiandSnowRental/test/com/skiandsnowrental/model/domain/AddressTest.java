package com.skiandsnowrental.model.domain;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class AddressTest {

	private Address address1, address2;
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before	
	public void setUp() throws Exception {

		address1 = new Address ("123 Main St", "Denver", "CO", "80218");
		address2 = new Address ("123 Main St", "Denver", "CO", "80218");

	}
	
	/**
	 * Test method for {@link com.skiandsnowrental.model.domain.Address#validate()}.
	 */
	@Test
	public final void testValidateAddress() {
		System.out.println("starting testValidateAddress()");
		address1 = new Address ("123 Main St", "Denver", "CO", "80218");
		// validate should assert to True since all variables 
		// being passed to create a new Customer are all valid.
		assertTrue ("address validates", address1.validate());
	       System.out.println("testValidate PASSED");
	}
	
	/**
	 * Test method for {@link com.skiandsnowrental.model.domain.Address#equals()}.
	 */
	@Test
	public final void testEqualsAddress()
	{
	System.out.println("starting testEqualsAddress()");
	assertTrue ("address1 equals address2", address1.equals(address2));
	 System.out.println("testEqualAddress PASSED");
	}
	
	/**
	 * Test method for {@link com.skiandsnowrental.model.domain.Address#equals()}.
	 */
	@Test
	public final void testNotEqualsAddress()
	{
	System.out.println("starting testNotEqualsAddress()");
	address2 = new Address ("123 Main St", "Aurora", "CO", "80218");
	assertFalse ("address1 equals address2", address1.equals(address2));
	 System.out.println("testNotEquals PASSED");
	}
}
