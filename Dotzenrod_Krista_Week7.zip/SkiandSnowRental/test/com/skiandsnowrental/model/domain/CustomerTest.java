package com.skiandsnowrental.model.domain;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class CustomerTest {

    private Customer customer1, customer2;

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {

        customer1 = new Customer("Jenner", "Kylie", "hello@gmail.com", "pass", "867.5309");
        customer2 = new Customer("Jenner", "Kylie", "hello@gmail.com", "pass", "867.5309");

    }

    /**
     * Test method for
     * {@link com.skiandsnowrental.model.domain.Customer#validate()}.
     */
    @Test
    public final void testValidateCustomer() {
        System.out.println("starting testValidateCustomer()");
        // validate should assert to True since all variables 
        // being passed to create a new Customer are all valid.
        assertTrue("customer validates", customer1.validate());
        System.out.println("testValidate PASSED");
    }

    /**
     * Test method for
     * {@link com.skiandsnowrental.model.domain.Customer#equals()}.
     */
    @Test
    public final void testNotEqualsCustomer() {
        System.out.println("starting testNotEqualsCustomer()");
        customer2 = new Customer("Jenner", "Kendall", "hello@gmail.com", "pass", "867.5309");
        assertFalse("c1 equals c2", customer1.equals(customer2));
        System.out.println("testNotEquals PASSED");
    }

    /**
     * Test method for
     * {@link com.skiandsnowrental.model.domain.Customer#equals()}.
     */
    @Test
    public final void testEqualsCustomer() {
        System.out.println("starting testEqualsCustomer()");
        assertFalse("c1 equals c2", customer1.equals(customer2));
        System.out.println("testEquals PASSED");
    }

}
