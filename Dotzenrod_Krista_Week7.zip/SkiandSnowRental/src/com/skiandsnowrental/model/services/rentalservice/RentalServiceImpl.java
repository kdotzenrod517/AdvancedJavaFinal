package com.skiandsnowrental.model.services.rentalservice;

import com.skiandsnowrental.model.dao.ISkiandSnowRentalDao;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;

import com.skiandsnowrental.model.domain.Rental;
import com.skiandsnowrental.model.domain.RentalComposite;
import com.skiandsnowrental.model.services.exception.DaoLoadException;
import com.skiandsnowrental.model.services.exception.RentalException;
import com.skiandsnowrental.model.services.factory.DAOFactory;
import org.apache.log4j.Logger;

public class RentalServiceImpl implements IRentalService {

    static Logger log = Logger.getLogger("skiandsnowrental");

    /**
     * Stores the customers rental into the database
     * @param Rental contains the rental info
     * @throws IOException
     */
    public boolean isRentalAvailable(RentalComposite rentalComposite) throws RentalException {
        boolean status = false;
        try {
            // Fetch the DAO Implementation
            ISkiandSnowRentalDao skiandSnowRentalDao = DAOFactory.getDao();
            // Reserve the car
            status = skiandSnowRentalDao.isRentalAvailable(rentalComposite);
        } //end reserveRentalCar
        catch (DaoLoadException ex) {
            // We are not propagating exception, with the intent that the 
            // RentalComposite will hold the state reflecting(null AvailableRentals
            // for example) an anomaly
            log.error("DAO Load Exception", ex);
        }
        return status;
        /*boolean isValid = false;
        ObjectInputStream input = null;
        try {
            input = new ObjectInputStream(new FileInputStream("Rental.out"));
            Rental savedRental = (Rental) input.readObject();
            Rental inRental = rentalComposite.getRental();
            if (inRental != null) {
                if (savedRental.equals(inRental)) {
                    isValid = true;
                } else {
                    isValid = false;
                }
            } else {

                throw new RentalException("Null Rental passed to RentalServiceImpl::rental");
            }
        } catch (FileNotFoundException fnfe) {
            log.error("File containing available rentals not found!");
            throw new RentalException("File containing available rentals not found!", fnfe);
        } catch (IOException ioe) {
            log.error("IOException while accessing file containing available rentals!");
            throw new RentalException("IOException while accessing file containing available rentals!", ioe);
        } catch (ClassNotFoundException cnfe) {
            log.error("ClassNotFoundException while reading file containing available rentals!");
            throw new RentalException("ClassNotFoundException while reading file containing available rentals!", cnfe);
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } // end try/catch/finally
        return isValid;*/
    } // end rental

   /** public static void main(String args[]) {

        RentalServiceImpl rentalServiceImpl = new RentalServiceImpl();
        rentalServiceImpl.serializeRental("28.9", "Skis", "Poles");

        // Create a Vector using an initial capacity of 10 elements
        // and increment it by 1 rental
        ArrayList<String> availableRentalsList = new ArrayList<String>();
        // add elements to vector
        availableRentalsList.add("Skis");
        availableRentalsList.add("Snowboard");
        availableRentalsList.add("Helmet");
        availableRentalsList.add("Poles");

        System.out.println("Initial rentals available : " + availableRentalsList);

        int myVecIndex = 0; // set index to first element

        // get first element in vector
        String firstElement = availableRentalsList.get(myVecIndex);
        System.out.println("First rental : " + firstElement);

        // get next element in vector
        myVecIndex++;
        System.out.println("Next rental : " + availableRentalsList.get(myVecIndex));

    }

    public void serializeRental(String rate, String rentalType, String extrasIncluded) {

        Rental rental = new Rental();
        rental.setRate("28.9");
        rental.setRentalType("Skis");
        rental.setExtrasIncluded("Poles");

        try {

            FileOutputStream fout = new FileOutputStream("Rental.out");
            ObjectOutputStream oos = new ObjectOutputStream(fout);
            oos.writeObject(rental);
            oos.close();
            log.info("Done");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
*/
}
