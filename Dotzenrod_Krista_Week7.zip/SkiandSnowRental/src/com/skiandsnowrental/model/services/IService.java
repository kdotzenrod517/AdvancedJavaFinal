/**
 * 
 */
package com.skiandsnowrental.model.services;

/**
 * @author kdotz Allows for just one service needing to be called
 *
 */
public interface IService {

}
