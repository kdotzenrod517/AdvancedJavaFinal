/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.model.services.factory;

/*
* author: kdotz
 */
import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateSessionFactory {

    static Logger log = Logger.getLogger("skiandsnowrental");

    private static String CONFIG_FILE_LOCATION = "hibernate.cfg.xml";

    /**
     * Holds a single instance of Session
     */
    private static final ThreadLocal threadLocal = new ThreadLocal();

    /**
     * The single instance of hibernate configuration
     */
    private static final Configuration cfg = new Configuration();

    /**
     * The single instance of hibernate SessionFactory
     */
    private static org.hibernate.SessionFactory sessionFactory;

    private static ServiceRegistry serviceRegistry;

    /**
     * Returns the ThreadLocal Session instance. Lazy initialize the
     * <code>SessionFactory</code> if needed.
     *
     * @return Session
     * @throws HibernateException
     */
    public static Session currentSession() throws HibernateException {
        Session session = (Session) threadLocal.get();

        if (session == null || !session.isOpen()) {
            if (sessionFactory == null) {
                try {
                    cfg.configure(CONFIG_FILE_LOCATION);

                    serviceRegistry = new StandardServiceRegistryBuilder().applySettings(
                            cfg.getProperties()).build();
                    sessionFactory = cfg.buildSessionFactory(serviceRegistry);

                } catch (Exception e) {
                    log.error("%%%% Error Creating SessionFactory %%%%", e);
                }
            }
            session = (sessionFactory != null) ? sessionFactory.openSession() : null;
            threadLocal.set(session);
        }
        return session;
    }

    /**
     * Close the single hibernate session instance.
     *
     * @throws HibernateException
     */
    public static void closeSession() throws HibernateException {
        Session session = (Session) threadLocal.get();
        threadLocal.set(null);

        if (session != null) {
            session.close();
        }
    }

    /**
     * Default constructor.
     */
    private HibernateSessionFactory() {
    }

}
