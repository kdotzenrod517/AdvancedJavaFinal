package com.skiandsnowrental.model.services.exception;

/**
 * @author krista.dotzenrod
 *
 */
public class CustomerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerException(final String inMessage) {
		super(inMessage); // call base class constructor
	}

	public CustomerException(final String inMessage, final Throwable inNestedException) {
		super(inMessage, inNestedException);
	}

}
