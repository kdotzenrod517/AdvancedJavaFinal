/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.model.business.manager;

/**
 *
 * @author kdotz
 */
import com.skiandsnowrental.model.business.exception.PropertyFileNotFoundException;
import com.skiandsnowrental.model.business.exception.ServiceLoadException;
import com.skiandsnowrental.model.domain.RentalComposite;
import com.skiandsnowrental.model.services.exception.RentalException;
import com.skiandsnowrental.model.services.factory.ServiceFactory;
import com.skiandsnowrental.model.services.rentalservice.IRentalService;
import java.util.logging.Level;
import org.apache.log4j.Logger;

public class DAOManager extends ManagerSuperType {

    /*
	 * Category set in config/log4j.properties as
	 * log4j.category.com.classexercise=DEBUG, A1
     */
    static Logger log = Logger.getLogger("skiandsnowrental");

    private static DAOManager _instance;

    /**
     * keep the constructor private to prevent instantiation by outside callers.
     */
    private DAOManager() {

    }

    /**
     * Assures that there is only one SkiandSnowRentalManager created.
     *
     * @return SkiandSnowRentalManager instance
     */
    public static synchronized DAOManager getInstance() {
        if (_instance == null) {
            _instance = new DAOManager();
        }
        return _instance;
    }

    /**
     * Method delegates to the ServiceFactory to execute a service. Good part of
     * this approach is that the Manager knows the service by a string name -
     * thus achieving the decoupling effect that we so desire in the MVC
     * approach.
     *
     * @param commandString - contains the service that needs to be performed
     * @param rentalComposite - contains the info needed by the above service.
     * null if fatal issues encountered.
     */
    @Override
    public boolean performAction(String commandString, RentalComposite rentalComposite) {
        boolean status = false;
        switch (commandString) {
            case "ValidateRental":
        {
            try {
                status = reserveRental(IRentalService.NAME, rentalComposite);
            } catch (RentalException ex) {
                java.util.logging.Logger.getLogger(DAOManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
                break;
        }
        return status;
    }//end performaAction

    private boolean reserveRental(String commandString, RentalComposite rentalComposite) throws RentalException {
        boolean status = false;
        ServiceFactory serviceFactory = ServiceFactory.getInstance();
        IRentalService iRentalService;

        try {
            iRentalService = (IRentalService) serviceFactory.getService(commandString);
            status = iRentalService.isRentalAvailable(rentalComposite);
        } catch (ServiceLoadException e) {
            log.error("DAOManager::isRentalAvailable failed", e);
        }
        return status;
    }//end isRentalAvailable

    /**
     * Not really used in this application. But is here in case we want to test
     * this class standalone.
     *
     * @param args
     */
    public static void main(String[] args) {
        try {
            DAOManager.loadProperties();
        } catch (PropertyFileNotFoundException pfnfe) {
            log.error("Application Properties failed to be loaded - Server will exit", pfnfe);
        }
    } //end main

} // end class SkiandSnowRentalServerManager
