/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.model.dao.hibernate;

/**
 *
 * @author kdotz
 */
import com.skiandsnowrental.model.dao.ISkiandSnowRentalDao;
import com.skiandsnowrental.model.domain.AvailableRentals;
import com.skiandsnowrental.model.domain.Rental;
import com.skiandsnowrental.model.domain.RentalComposite;
import com.skiandsnowrental.model.services.factory.HibernateSessionFactory;
import java.util.List;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;

public class SkiandSnowRentalHibernateDaoImpl implements ISkiandSnowRentalDao {

    static Logger log = Logger.getLogger("skiandsnowrental");

    /**
     * Retrieve all the rentals that are available based on criteria in the
     * Rental objects
     */
    public boolean getAvailableRentals(RentalComposite rentalComposite) {
        boolean status = false;

        log.info("-------------------------------");
        log.info("Using Hibernate Implementation");
        log.info("-------------------------------");

        log.info("Available Rentals");
        AvailableRentals availableRentals = null;

        //Session session = fetchSession();
        availableRentals = fetchAvailableRentals();

        if (availableRentals != null) {
            // indicate that rentals are available for customer's request
            availableRentals.setAvailable(true);
            // set available rentals into the rental composite
            rentalComposite.setAvailableRentals(availableRentals);

            // set the return status
            status = true;
        }
        return status;
    } //end getAvailableRentals

    /**
     * Gets a hibernate session from HibernateSessionFactory
     *
     * @return org.hibernate.Session
     *
     */
    private Session fetchSession() {
        log.info("******Fetching Hibernate Session");

        Session session = HibernateSessionFactory.currentSession();

        return session;

    } //end fetchConnection

    /**
     * Fetches all available rentals
     *
     * @return List containing all available rentals
     */
    private AvailableRentals fetchAvailableRentals() {
        AvailableRentals availableRentals = null;
        List<Rental> rentalList = null;

        Session session = fetchSession();
        session.beginTransaction();

        Query query = session.createQuery("select c.rate, c.rentalType, c.extrasIncluded from rental c");

        log.info("About to display the queried list");

        rentalList = query.list();
        availableRentals = buildAvailableRentals(rentalList);

        session.getTransaction().commit();
        session.close();

        return availableRentals;

    } // fetchAvailableRentals

    /**
     * Iterate over the List and build out the AvailableRentals object.
     *
     * @param List containing the available rentals
     *
     * @return AvailableRentals
     */
    private AvailableRentals buildAvailableRentals(List<Rental> rentalList) {
        log.info("Inside buildAvailableRentals");
        AvailableRentals availableRentals = new AvailableRentals();

        for (Rental rental : rentalList) {
            availableRentals.addRental(rental);
        }
        return availableRentals;
    } // end buildAvailableRentals

    @Override
    public boolean isRentalAvailable(RentalComposite rentalComposite) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean authenticateCustomer(RentalComposite _rentalComposite) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

} // end class SkiandSnowRentalHibernateDaoImpl
