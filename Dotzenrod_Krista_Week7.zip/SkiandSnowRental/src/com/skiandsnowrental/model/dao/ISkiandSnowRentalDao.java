/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.model.dao;

import com.skiandsnowrental.model.domain.RentalComposite;

/**
 *
 * @author kdotz
 */
public interface ISkiandSnowRentalDao {

    public boolean isRentalAvailable (RentalComposite rentalComposite);

    public boolean authenticateCustomer (RentalComposite _rentalComposite);

}
