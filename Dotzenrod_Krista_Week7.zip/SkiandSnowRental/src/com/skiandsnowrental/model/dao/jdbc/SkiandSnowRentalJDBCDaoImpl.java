package com.skiandsnowrental.model.dao.jdbc;

import com.skiandsnowrental.model.dao.ISkiandSnowRentalDao;
import com.skiandsnowrental.model.domain.AvailableRentals;
import com.skiandsnowrental.model.domain.Rental;
import com.skiandsnowrental.model.domain.RentalComposite;
import com.skiandsnowrental.model.services.manager.SAXPropertyManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.log4j.Logger;

/**
 *
 * @author kdotz
 *
 *
 */
public class SkiandSnowRentalJDBCDaoImpl implements ISkiandSnowRentalDao {

    static Logger log = Logger.getLogger("skiandsnowrental");

    /**
     * Using the connection parameters from the property files, loads and
     * registers the JDBC driver and gets the database connection and returns
     * in.
     *
     * @return Connection Connection returned on success otherwise returns null
     * @throws SQLException
     */
    public Connection fetchConnection() {
        log.info("Fetching Database Connection");
        Connection conn = null;

        String url = SAXPropertyManager.getPropertyValue("jdbc.url");
        String userid = SAXPropertyManager.getPropertyValue("jdbc.user");
        String password = SAXPropertyManager.getPropertyValue("jdbc.password");

        //load and register JDBC driver then connect to database
        try {
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            conn = DriverManager.getConnection(url, userid, password);
        } catch (SQLException e) {
            log.error("Could not load and register JDBC driver or connect to database.");
            log.error(e.getClass() + ": " + e.getMessage(), e);
        }
        return conn;
    } //end fetchConnection

    /**
     * Retrieve all the rentals that are available based on criteria in the
     * Itinerary object and populate AvailableRentals
     *
     * @return boolean true if rentals are available, else false
     * @return RentalComposite has availableRentals set if rentals are available
     */
    @Override
    public boolean isRentalAvailable(RentalComposite rentalComposite) {
        boolean status = false;

        log.info("-------------------------------");
        log.info("Using JDBC Implementation");
        log.info("-------------------------------");

        log.info("Inside Get Available Rentals");

        AvailableRentals availableRentals = fetchAvailableRentals();

        if (availableRentals != null) {
            // indicate that rentals are available for customer'stmt request
            availableRentals.setAvailable(true);
            // set available rentals into the rental composite
            rentalComposite.setAvailableRentals(availableRentals);

            // set the return status
            status = true;
        }
        return status;
    } //end getAvailableRentals

    /**
     * Fetches all available rentals
     *
     * @return AvailableRentals containing all available rentals null, if no
     * connection available to the db
     */
    public AvailableRentals fetchAvailableRentals() {
        AvailableRentals availableRentals = null;
        ResultSet rset = null;
        Statement stmt = null;
        Connection conn = null;
        try {
            // Create a connection
            conn = fetchConnection();

            if (conn != null) {
                // Create a statement.
                stmt = conn.createStatement();

                rset = stmt.executeQuery("select c.rate, c.rentalType, c.extrasIncluded from rental c");

                availableRentals = buildAvailableRentals(rset);
            }
        } catch (SQLException e) {
            log.error(e.getClass() + ": " + e.getMessage(), e);
        } finally //must close resources in finally block
        {
            try {
                // check for null first before closing resources
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {// No need to propagate as availableRentals state conveys										
                log.error(e.getClass() + ": " + e.getMessage(), e);
            }
        }
        return availableRentals;
    } // fetchAvailableRentals

    /**
     * Iterate over the result set and build out the AvailableRentals object.
     *
     * @param resultSet
     * @return AvailableRentals populated if resultSet contains data Returns a
     * null AvailableRentals otherwise
     */
    private AvailableRentals buildAvailableRentals(ResultSet resultSet) {
        log.info("Inside buildAvailableRentals");
        AvailableRentals availableRentals = null;

        try {
            // Note: isBeforeFirst: true if the cursor is before the first row; false if 
            // the cursor is at any other position or the result set contains no rows 
            // Create availableRentals, only if resultSet has data.
            if (resultSet.isBeforeFirst()) {
                availableRentals = new AvailableRentals();
            }

            while (resultSet.next()) {

                Rental rental = new Rental (resultSet.getString(1),
                        resultSet.getString(2),
                        resultSet.getString(3));

                availableRentals.addRental(rental);
            }
        } catch (SQLException e) {// No need to propagate as availableRentals state conveys								
            log.error(e.getClass() + ": " + e.getMessage(), e);
        }
        return availableRentals;
    } // end buildAvailableRentals

    @Override
    public boolean authenticateCustomer(RentalComposite _rentalComposite) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
} // end class SkiandSnowRentalJDBCDaoImpl
