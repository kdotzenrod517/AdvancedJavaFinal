/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.server;

/**
 *
 * @author kdotz
 */
import com.skiandsnowrental.model.business.manager.*;
import com.skiandsnowrental.model.domain.RentalComposite;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import org.apache.log4j.Logger;

/**
 * Class that connects SkiandSnowRentalServer to the SkiandSnowRentalManager
 *
 *
 */
public class SkiandSnowRentalMultiThreadedServerHandler extends Thread {

  
    private Socket incomingSocket;
    private final int threadNumber;
    /*
			* Category set in config/log4j.properties as
			* log4j.category.com.classexercise=DEBUG, A1
     */
    static Logger log = Logger.getLogger("skiandsnowrental");
    /**
     * overloaded ctor
     *
     * @param _incomingSocket - from client
     */
    public SkiandSnowRentalMultiThreadedServerHandler(Socket _incomingSocket, int _threadNumber) {
        incomingSocket = _incomingSocket;
        threadNumber = _threadNumber;
    }

    /**
     * Extracts the objects from the Socket and invokes performAction method on
     * it.
     *
     * Writes back on the socket the updated RentalComposite object
     *
     */
    public void run() {
        ObjectInputStream in = null;
        ObjectOutputStream out = null;

        try {
            in = new ObjectInputStream(incomingSocket.getInputStream());
            out = new ObjectOutputStream(incomingSocket.getOutputStream());

            // retrieve the commandString
            String commandString = (String) in.readObject();

            log.info("SkiandSnowRentalServerHandler::run:Received command to execute service: " + commandString);

            // retrieve object sent by Client over the ObjectInputStream
            RentalComposite rentalComposite = (RentalComposite) in.readObject();

            // Now as in the past, call the manager to perform action.
            SkiAndSnowRentalManager skiandSnowRentalServerManager = SkiAndSnowRentalManager.getInstance();
            boolean status = skiandSnowRentalServerManager.performAction(commandString, rentalComposite);

            // return modified object back to Client over the ObjectOutputStream
            out.writeObject(status);
            out.writeObject(rentalComposite);
            out.flush();

        } catch (Exception e) {
            log.error("Error processing request from client", e);
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
                if (incomingSocket != null) {
                    incomingSocket.close();
                }
            } catch (IOException e) {
                log.error(e.getClass() + ": " + e.getMessage(), e);
            }
            log.info(threadNumber + " exiting");
        }//end try/catch/finally
    }//end run    
} // end class SkiandSnowRentalMultiThreadedServerHandler
