/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.server;

/**
 *
 * @author kdotz
 */
import java.net.ServerSocket;
import java.net.Socket;
import org.apache.log4j.Logger;

/**
 *   *
 * @author Mike.Prasad
 *
 */
public class SkiandSnowRentalMultiThreadedServer {
    
    private static int threadsCreated = 1;

    /*
			* Category set in config/log4j.properties as
			* log4j.category.com.classexercise=DEBUG, A1
     */
    static Logger log = Logger.getLogger("skiandsnowrental");

    /**
     * keep the constructor private to prevent instantiation by outside callers.
     */
    private SkiandSnowRentalMultiThreadedServer() {
        
    }

    /**
     *
     * Fires up the server
     */
    public static void startServer() {
        try {
            log.info("Ski and Snow Rental Server Started");

            ServerSocket s = new ServerSocket(8192); // port should come from a properties file

            for (;;) {
                Socket socket = s.accept();

                // Call the handler to process request								   
            
                SkiandSnowRentalMultiThreadedServerHandler skiandSnowRentalMultiThreadedServerHandler = new SkiandSnowRentalMultiThreadedServerHandler(socket, threadsCreated);
                skiandSnowRentalMultiThreadedServerHandler.start();
                log.info("Threads created: " + threadsCreated);
                
                threadsCreated++;
            }
        } catch (Exception e) {
            log.error("Issue starting SkiandSnowRental Server ", e);
        }

    } //end startServer

    /**
     * Starts the server
     *
     * @param args
     */
    public static void main(String[] args) {
        SkiandSnowRentalMultiThreadedServer.startServer();
    }//end main
} // end class SkiandSnowRentalMultiThreadedServer
