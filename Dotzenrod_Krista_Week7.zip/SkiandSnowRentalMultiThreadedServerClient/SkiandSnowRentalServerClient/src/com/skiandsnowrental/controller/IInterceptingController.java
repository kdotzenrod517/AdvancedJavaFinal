/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.controller;

import com.skiandsnowrental.model.domain.RentalComposite;

/**
 *
 * @author kdotz
 */
public interface IInterceptingController
{
    public boolean performAction(String commandString, RentalComposite rentalComposite);
    
} // end class InterceptingController