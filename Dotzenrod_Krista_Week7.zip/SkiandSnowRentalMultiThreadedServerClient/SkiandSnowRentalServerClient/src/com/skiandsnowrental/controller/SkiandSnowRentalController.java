/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.skiandsnowrental.controller;

/**
 *
 * @author kdotz
 */
import com.skiandsnowrental.model.domain.RentalComposite;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import org.apache.log4j.Logger;

/**
 * This class is the Controller in the MVC framework. View classes call into the
 * Controller and as such have no visibility into the Model.
 *
 * This controller uses a socket connection to connect to the ServerSocket which
 * happens to be the Model's SkiandSnowRentalServerManager.
 *
 */
public class SkiandSnowRentalController implements IInterceptingController {

    static Logger log = Logger.getLogger("skiandsnowrental");
  
    @Override
    public boolean performAction(String commandString, RentalComposite rentalComposite) {
        boolean status = false;
        Socket socket = null;
        ObjectOutputStream out = null;
        ObjectInputStream is = null;

        try {
            System.out.println("About to make a socket connection to the server");
            // Step 1: Create Socket to make a connection		 
            socket = new Socket(InetAddress.getLocalHost(), 8192);

            // Step 2: Get input and output streams
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();

            // Create an object to be sent to Server for processing.
            //out.writeObject ("ProcessValidateRental");
            out.writeObject(commandString);
            out.writeObject(rentalComposite);

            // Step 3: Process data sent back from Server
            is = new ObjectInputStream(socket.getInputStream());
            status = (Boolean) is.readObject();
            rentalComposite = (RentalComposite) is.readObject(); // get what server has to say

        } catch (Exception e) {
            log.error(e.getClass() + ": " + e.getMessage(), e);
        } // Step 4: Close connection
        finally {
            // Step 4: Close connection
            try {
                if (is != null) {
                    is.close();
                }
                if (out != null) {
                    out.close();
                }
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                log.error(e.getClass() + ": " + e.getMessage(), e);
            }
        }//end try/catch/finally				
        return status;
    } //end performAction
} // end class SkiandSnowRentalController
